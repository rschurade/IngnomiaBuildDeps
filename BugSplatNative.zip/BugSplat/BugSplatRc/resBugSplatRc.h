//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by BugSplatRc.rc
//
#define IDDETAILS                       4
#define IDDETAILS2                      5
#define IDI_TICK                        101
#define IDI_ERR                         102
#define IDC_OPTIN                       999
#define IDD_CRASHREPORT                 1000
#define IDD_PROGRESS                    1001
#define IDC_CRASHDLGHEADER              1001
#define IDC_EDIT_DESCRIPTION            1001
#define IDC_EDIT_NAME                   1002
#define IDC_EDIT_POSTALADDRESS          1003
#define IDD_REPORTDETAILS               1003
#define IDC_EDIT_EMAILADDRESS           1004
#define IDD_REPORTFILES                 1004
#define IDS_PLEASETELL_VENDOR           1005
#define IDC_SENDPROGRESS                1006
#define IDC_TASK1                       1007
#define IDC_STATIC_MSG1                 1007
#define IDC_TASK2                       1008
#define IDC_HYPERLINK                   1008
#define IDC_TASK3                       1009
#define IDC_EDIT1                       1009
#define IDC_REPORTDETAILS               1010
#define IDC_COMPLETE                    1010
#define IDC_LISTFILES                   1011
#define IDC_CHECK1                      1012
#define IDC_SENDADDITIONALFILES         1012
#define IDC_ADDITIONALFILEREQUEST       1013
#define IDS_FAILED                      3000
#define IDS_UNKNOWNERR                  3001
#define IDS_CREATEREPORT_FAILED         3002
#define IDS_FAILED_DMP_SAVE             3003
#define IDS_FAILED_DMP_CREATE           3004
#define IDS_OLD_DBGHELP                 3005
#define IDS_NOEXIST_DBGHELP             3006
#define IDS_UNABLETOVALIDATESERVER      3007
#define IDS_UNABLETOCOLLECTDATA         3008
#define IDS_UNABLETOREACHSERVER         3009
#define IDS_INVALIDSERVERRESPONSE       3010
#define IDS_LISTHEADER_FILE             3011
#define IDS_LISTHEADER_FILEFOLDER       3012
#define IDS_NEEDTODOWNLOADCOMPONENT     3013
#define IDS_NEEDTODOWNLOADNEWERCOMPONENT 3014
#define IDS_HUNG_SHUTDOWN               3015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1005
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           1000
#endif
#endif
